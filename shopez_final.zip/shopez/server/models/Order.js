import mongoose from "mongoose"

const orderSchema = new mongoose.Schema({

 userId:{
  type:mongoose.Schema.Types.ObjectId,
  ref:"User"
 },

 items:[
  {
   productId:{
    type:mongoose.Schema.Types.ObjectId,
    ref:"Product"
   },
   quantity:Number,
   size:String
  }
 ],

 address:String,
 pincode:String,
 paymentMethod:String,

 orderStatus:{
  type:String,
  default:"Order Placed"
 },

 orderDate:{
  type:Date,
  default:Date.now
 }

})

export default mongoose.model("Order",orderSchema)