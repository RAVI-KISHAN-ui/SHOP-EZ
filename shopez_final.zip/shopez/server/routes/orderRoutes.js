import express from "express";
import Order from "../models/Order.js";

const router = express.Router();

/* Get ALL orders (admin dashboard) */
router.get("/", async (req, res) => {

  try {

    const orders = await Order.find();
    res.json(orders);

  } catch (err) {

    res.status(500).json({ error: err.message });

  }

});

/* Get orders by USER ID */
router.get("/:userId", async (req, res) => {

  try {

    const orders = await Order.find({
      userId: req.params.userId
    });

    res.json(orders);

  } catch (err) {

    res.status(500).json({ error: err.message });

  }

});

export default router;