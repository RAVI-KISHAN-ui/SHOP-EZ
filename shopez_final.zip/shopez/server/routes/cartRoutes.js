import express from "express"

import {
 addToCart,
 getCart,
 removeCartItem
} from "../controllers/cartController.js"

import {verifyToken} from "../middleware/authMiddleware.js"

const router = express.Router()

router.post("/",verifyToken,addToCart)

router.get("/:userId",verifyToken,getCart)

router.delete("/:id",verifyToken,removeCartItem)

export default router