import jwt from "jsonwebtoken"

export const verifyToken = (req,res,next)=>{

 const token = req.headers.authorization?.split(" ")[1]

 if(!token){
  return res.status(401).json("Access denied")
 }

 try{

 const decoded = jwt.verify(token,process.env.JWT_SECRET)

 req.user = decoded

 next()

 }catch(err){
  res.status(403).json("Invalid token")
 }

}