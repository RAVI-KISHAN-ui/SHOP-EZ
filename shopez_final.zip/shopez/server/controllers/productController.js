import Product from "../models/Product.js"

export const createProduct = async(req,res)=>{

 try{

 const product = new Product(req.body)

 await product.save()

 res.json(product)

 }catch(err){

 res.status(500).json(err)

 }

}

export const getProducts = async(req,res)=>{

 try{

 const products = await Product.find()

 res.json(products)

 }catch(err){

 res.status(500).json(err)

 }

}

export const getProductById = async(req,res)=>{

 try{

 const product = await Product.findById(req.params.id)

 res.json(product)

 }catch(err){

 res.status(500).json(err)

 }

}

export const updateProduct = async(req,res)=>{

 try{

 const product = await Product.findByIdAndUpdate(
 req.params.id,
 req.body,
 {new:true}
 )

 res.json(product)

 }catch(err){

 res.status(500).json(err)

 }

}

export const deleteProduct = async(req,res)=>{

 try{

 await Product.findByIdAndDelete(req.params.id)

 res.json("Product Deleted")

 }catch(err){

 res.status(500).json(err)

 }

}