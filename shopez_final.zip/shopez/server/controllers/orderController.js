import Order from "../models/Order.js"

export const placeOrder = async(req,res)=>{

 try{

 const order = new Order(req.body)

 await order.save()

 res.json(order)

 }catch(err){

 res.status(500).json(err)

 }

}

export const getUserOrders = async(req,res)=>{

 try{

 const orders = await Order.find({userId:req.params.userId})

 res.json(orders)

 }catch(err){

 res.status(500).json(err)

 }

}

export const updateOrderStatus = async(req,res)=>{

 try{

 const order = await Order.findByIdAndUpdate(
 req.params.id,
 {orderStatus:req.body.status},
 {new:true}
 )

 res.json(order)

 }catch(err){

 res.status(500).json(err)

 }

}