import Cart from "../models/Cart.js"

export const addToCart = async(req,res)=>{

 try{

 const cartItem = new Cart(req.body)

 await cartItem.save()

 res.json(cartItem)

 }catch(err){

 res.status(500).json(err)

 }

}

export const getCart = async(req,res)=>{

 try{

 const cart = await Cart.find({userId:req.params.userId})
 .populate("productId")

 res.json(cart)

 }catch(err){

 res.status(500).json(err)

 }

}

export const removeCartItem = async(req,res)=>{

 try{

 await Cart.findByIdAndDelete(req.params.id)

 res.json("Item removed")

 }catch(err){

 res.status(500).json(err)

 }

}