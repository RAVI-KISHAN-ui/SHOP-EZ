import User from "../models/User.js"
import bcrypt from "bcryptjs"
import jwt from "jsonwebtoken"

export const register = async(req,res)=>{

 try{

 const {username,email,password,usertype} = req.body

 const hashed = await bcrypt.hash(password,10)

 const user = new User({
  username,
  email,
  password:hashed,
  usertype
 })

 await user.save()

 res.json("User Registered")

 }catch(err){
  res.status(500).json(err)
 }

}

export const login = async(req,res)=>{

 try{

 const {email,password} = req.body

 const user = await User.findOne({email})

 if(!user) return res.status(400).json("User not found")

 const valid = await bcrypt.compare(password,user.password)

 if(!valid) return res.status(400).json("Invalid password")

 const token = jwt.sign(
  {id:user._id,usertype:user.usertype},
  process.env.JWT_SECRET
 )

 res.json({
  token,
  user
 })

 }catch(err){
  res.status(500).json(err)
 }

}