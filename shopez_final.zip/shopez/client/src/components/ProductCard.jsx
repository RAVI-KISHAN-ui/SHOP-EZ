import API from "../services/api";

function ProductCard({ product }) {

  const user = JSON.parse(localStorage.getItem("user"));

  const addToCart = async () => {

    if (!user) {
      alert("Please login first");
      return;
    }

    try {

      await API.post("/cart", {
        userId: user._id,
        productId: product._id,
        quantity: 1,
        size: "M"
      });

      alert("Product added to cart");

    } catch (error) {
      console.error(error);
      alert("Error adding to cart");
    }

  };

  return (

    <div className="col-md-3 mb-4">

      <div className="card shadow h-100">

        <img
          src={product.mainImg || "https://via.placeholder.com/200"}
          alt={product.title}
          className="card-img-top"
          style={{ height: "200px", objectFit: "cover" }}
        />

        <div className="card-body d-flex flex-column">

          <h5 className="card-title">
            {product.title || "Product"}
          </h5>

          <p className="card-text text-muted">
            {typeof product.description === "string"
              ? product.description.substring(0, 60)
              : "No description"}
          </p>

          <p className="text-success fw-bold">
            ₹{product.price || 0}
          </p>

          {product.discount && (
            <p className="text-danger">
              {product.discount}% OFF
            </p>
          )}

          <button
            className="btn btn-primary mt-auto"
            onClick={addToCart}
          >
            Add to Cart
          </button>

        </div>

      </div>

    </div>

  );
}

export default ProductCard;