import {Link} from "react-router-dom"

function Navbar(){

const user = JSON.parse(localStorage.getItem("user"))

return(

<nav className="navbar navbar-dark bg-primary p-3">

<div className="container">

<Link className="navbar-brand" to="/">ShopEZ</Link>

<div>

<Link className="btn btn-light me-2" to="/products">
Products
</Link>

{user && (
<Link className="btn btn-light me-2" to="/cart">
Cart
</Link>
)}

{user && (
<Link className="btn btn-light me-2" to="/orders">
Orders
</Link>
)}

{!user ? (
<Link className="btn btn-light" to="/login">
Login
</Link>
):(
<button
className="btn btn-danger"
onClick={()=>{

localStorage.clear()
window.location.reload()

}}
>
Logout
</button>
)}

</div>

</div>

</nav>

)

}

export default Navbar