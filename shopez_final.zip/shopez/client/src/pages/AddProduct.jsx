import {useState} from "react"
import API from "../services/api"

function AddProduct(){

const [form,setForm] = useState({})

const submit = async(e)=>{

e.preventDefault()

await API.post("/products",form)

alert("Product added")

}

return(

<div className="container mt-5">

<h3>Add Product</h3>

<form onSubmit={submit}>

<input
className="form-control mb-3"
placeholder="Title"
onChange={(e)=>setForm({...form,title:e.target.value})}
/>

<input
className="form-control mb-3"
placeholder="Description"
onChange={(e)=>setForm({...form,description:e.target.value})}
/>

<input
className="form-control mb-3"
placeholder="Image URL"
onChange={(e)=>setForm({...form,mainImg:e.target.value})}
/>

<input
className="form-control mb-3"
placeholder="Price"
onChange={(e)=>setForm({...form,price:e.target.value})}
/>

<button className="btn btn-primary">
Add Product
</button>

</form>

</div>

)

}

export default AddProduct