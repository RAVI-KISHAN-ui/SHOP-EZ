function Home(){

return(

<div>

<div className="bg-dark text-white text-center p-5">

<h1>Welcome to ShopEZ</h1>
<p>Your one stop shopping destination</p>

</div>

<div className="container mt-5">

<h3>Shop Categories</h3>

<div className="row">

<div className="col-md-2">Fashion</div>
<div className="col-md-2">Electronics</div>
<div className="col-md-2">Mobiles</div>
<div className="col-md-2">Groceries</div>
<div className="col-md-2">Sports</div>

</div>

</div>

</div>

)

}

export default Home