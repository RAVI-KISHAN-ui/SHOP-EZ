import { useEffect, useState } from "react";
import API from "../services/api";
import { useNavigate } from "react-router-dom";

function Cart() {

  const [cart, setCart] = useState([]);

  const user = JSON.parse(localStorage.getItem("user"));

  const navigate = useNavigate();

  const fetchCart = async () => {

    if (!user) return;

    try {

      const res = await API.get(`/cart/${user._id}`);
      setCart(res.data);

    } catch (error) {
      console.error(error);
    }

  };

  useEffect(() => {

    fetchCart();

  }, [user]);

  const removeItem = async (id) => {

    try {

      await API.delete(`/cart/${id}`);
      fetchCart();

    } catch (error) {
      console.error(error);
    }

  };

  const totalPrice = cart.reduce((sum, item) => {
    return sum + (item.productId?.price || 0);
  }, 0);

  return (

    <div className="container mt-4">

      <h2>Your Cart</h2>

      {cart.length === 0 ? (
        <p>Your cart is empty</p>
      ) : (

        <div className="row">

          <div className="col-md-8">

            {cart.map((item) => (

              <div key={item._id} className="card mb-3">

                <div className="row g-0">

                  <div className="col-md-4">

                    <img
                      src={item.productId?.mainImg}
                      className="img-fluid rounded-start"
                      alt="product"
                    />

                  </div>

                  <div className="col-md-8">

                    <div className="card-body">

                      <h5>{item.productId?.title}</h5>

                      <p>Price: ₹{item.productId?.price}</p>

                      <p>Size: {item.size}</p>

                      <button
                        className="btn btn-danger"
                        onClick={() => removeItem(item._id)}
                      >
                        Remove
                      </button>

                    </div>

                  </div>

                </div>

              </div>

            ))}

          </div>

          <div className="col-md-4">

            <div className="card p-3">

              <h4>Price Details</h4>

              <p>Total Items: {cart.length}</p>

              <h5>Total Price: ₹{totalPrice}</h5>

              <button
                className="btn btn-success w-100"
                onClick={() => navigate("/checkout")}
              >
                Place Order
              </button>

            </div>

          </div>

        </div>

      )}

    </div>

  );
}

export default Cart;