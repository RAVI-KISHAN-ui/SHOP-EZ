import {useState} from "react"
import API from "../services/api"
import {useNavigate} from "react-router-dom"

function Login(){

const [form,setForm] = useState({})

const navigate = useNavigate()

const login = async(e)=>{

e.preventDefault()

const res = await API.post("/auth/login",form)

localStorage.setItem("token",res.data.token)
localStorage.setItem("user",JSON.stringify(res.data.user))

navigate("/products")

}

return(

<div className="container mt-5">

<h3>Login</h3>

<form onSubmit={login}>

<input
className="form-control mb-3"
placeholder="Email"
onChange={(e)=>setForm({...form,email:e.target.value})}
/>

<input
type="password"
className="form-control mb-3"
placeholder="Password"
onChange={(e)=>setForm({...form,password:e.target.value})}
/>

<button className="btn btn-primary">
Login
</button>

</form>

</div>

)

}

export default Login