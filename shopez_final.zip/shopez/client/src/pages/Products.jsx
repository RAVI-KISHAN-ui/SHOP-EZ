import { useEffect, useState } from "react";
import API from "../services/api";
import ProductCard from "../components/ProductCard";

function Products() {

  const [products, setProducts] = useState([]);
  const [category, setCategory] = useState("");

  useEffect(() => {

    const fetchProducts = async () => {
      try {

        const res = await API.get("/products");

        // ensure products is always array
        if (Array.isArray(res.data)) {
          setProducts(res.data);
        } else {
          setProducts([]);
        }

      } catch (error) {
        console.error("Error fetching products:", error);
      }
    };

    fetchProducts();

  }, []);

  const filteredProducts = products.filter((p) => {
    if (!category) return true;
    return p.category === category;
  });

  return (

    <div className="container mt-4">

      <h2 className="mb-4">Products</h2>

      <div className="mb-4">

        <select
          className="form-select"
          onChange={(e) => setCategory(e.target.value)}
        >

          <option value="">All Categories</option>
          <option value="fashion">Fashion</option>
          <option value="electronics">Electronics</option>
          <option value="mobiles">Mobiles</option>
          <option value="sports">Sports</option>
          <option value="groceries">Groceries</option>

        </select>

      </div>

      <div className="row">

        {filteredProducts.length === 0 ? (
          <p>No products found</p>
        ) : (
          filteredProducts.map((product) => (
            <ProductCard key={product._id} product={product} />
          ))
        )}

      </div>

    </div>

  );
}

export default Products;