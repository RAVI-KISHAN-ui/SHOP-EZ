import {useState} from "react"
import API from "../services/api"
import {useNavigate} from "react-router-dom"

function Register(){

const [form,setForm] = useState({})

const navigate = useNavigate()

const submit = async(e)=>{

e.preventDefault()

await API.post("/auth/register",form)

navigate("/login")

}

return(

<div className="container mt-5">

<h3>Register</h3>

<form onSubmit={submit}>

<input
className="form-control mb-3"
placeholder="Username"
onChange={(e)=>setForm({...form,username:e.target.value})}
/>

<input
className="form-control mb-3"
placeholder="Email"
onChange={(e)=>setForm({...form,email:e.target.value})}
/>

<input
type="password"
className="form-control mb-3"
placeholder="Password"
onChange={(e)=>setForm({...form,password:e.target.value})}
/>

<select
className="form-control mb-3"
onChange={(e)=>setForm({...form,usertype:e.target.value})}
>

<option>Customer</option>
<option>Admin</option>

</select>

<button className="btn btn-primary">
Register
</button>

</form>

</div>

)

}

export default Register