import {useEffect,useState} from "react"
import API from "../services/api"

function Orders(){

const [orders,setOrders] = useState([])

const user = JSON.parse(localStorage.getItem("user"))

useEffect(()=>{

API.get(`/orders/${user._id}`)
.then(res=>setOrders(res.data))

},[])

return(

<div className="container mt-4">

<h3>Orders</h3>

{orders.map(order=>(

<div className="card p-3 mb-3">

<p>Status: {order.orderStatus}</p>

<p>Date: {order.orderDate}</p>

</div>

))}

</div>

)

}

export default Orders