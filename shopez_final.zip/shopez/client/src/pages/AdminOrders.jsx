import {useEffect,useState} from "react"
import API from "../services/api"

function AdminOrders(){

const [orders,setOrders] = useState([])

useEffect(()=>{

API.get("/admin/orders")
.then(res=>setOrders(res.data))

},[])

const updateStatus = async(id,status)=>{

await API.put(`/orders/${id}`,{
 status
})

alert("Status updated")

}

return(

<div className="container mt-5">

<h3>Manage Orders</h3>

{orders.map(order=>(

<div className="card p-3 mb-3">

<p>User: {order.userId}</p>
<p>Status: {order.orderStatus}</p>

<select
onChange={(e)=>updateStatus(order._id,e.target.value)}
>

<option>Order Placed</option>
<option>Shipped</option>
<option>Delivered</option>

</select>

</div>

))}

</div>

)

}

export default AdminOrders