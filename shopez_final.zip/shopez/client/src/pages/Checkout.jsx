import { useState, useEffect } from "react";
import API from "../services/api";
import { useNavigate } from "react-router-dom";

function Checkout() {

  const user = JSON.parse(localStorage.getItem("user"));
  const navigate = useNavigate();

  const [cart,setCart] = useState([]);

  const [form,setForm] = useState({
    address:"",
    pincode:"",
    paymentMethod:"COD"
  });

  const fetchCart = async () => {

    try {

      const res = await API.get(`/cart/${user._id}`);
      setCart(res.data);

    } catch (error) {
      console.error(error);
    }

  };

  useEffect(()=>{
    fetchCart();
  },[]);

  const placeOrder = async(e)=>{

    e.preventDefault();

    try{

      await API.post("/orders",{
        userId:user._id,
        items:cart,
        address:form.address,
        pincode:form.pincode,
        paymentMethod:form.paymentMethod
      });

      alert("Order placed successfully");

      navigate("/orders");

    }catch(err){
      console.log(err);
      alert("Error placing order");
    }

  };

  const totalPrice = cart.reduce((sum,item)=>{
    return sum + (item.productId?.price || 0);
  },0);

  return(

    <div className="container mt-5">

      <h3>Checkout</h3>

      <div className="mb-3">
        <strong>Total Price: ₹{totalPrice}</strong>
      </div>

      <form onSubmit={placeOrder}>

        <input
          className="form-control mb-3"
          placeholder="Address"
          required
          onChange={(e)=>setForm({...form,address:e.target.value})}
        />

        <input
          className="form-control mb-3"
          placeholder="Pincode"
          required
          onChange={(e)=>setForm({...form,pincode:e.target.value})}
        />

        <select
          className="form-control mb-3"
          onChange={(e)=>setForm({...form,paymentMethod:e.target.value})}
        >

          <option value="COD">Cash on Delivery</option>
          <option value="UPI">UPI</option>

        </select>

        <button className="btn btn-success">
          Place Order
        </button>

      </form>

    </div>

  );

}

export default Checkout;