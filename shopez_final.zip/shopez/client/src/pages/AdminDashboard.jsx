import {useEffect,useState} from "react"
import API from "../services/api"

function AdminDashboard(){

const [users,setUsers] = useState(0)
const [products,setProducts] = useState(0)
const [orders,setOrders] = useState(0)

useEffect(()=>{

fetchData()

},[])

const fetchData = async()=>{

try{

const usersRes = await API.get("/users")
const productsRes = await API.get("/products")
const ordersRes = await API.get("/orders")

setUsers(usersRes.data.length)
setProducts(productsRes.data.length)
setOrders(ordersRes.data.length)

}catch(err){

console.log(err)

}

}

return(

<div className="container mt-5">

<h2 className="mb-4">Admin Dashboard</h2>

<div className="row">

<div className="col-md-4">

<div className="card bg-dark text-white p-4">

<h4>Total Users</h4>
<h1>{users}</h1>

</div>

</div>

<div className="col-md-4">

<div className="card bg-primary text-white p-4">

<h4>Total Products</h4>
<h1>{products}</h1>

</div>

</div>

<div className="col-md-4">

<div className="card bg-success text-white p-4">

<h4>Total Orders</h4>
<h1>{orders}</h1>

</div>

</div>

</div>

</div>

)

}

export default AdminDashboard